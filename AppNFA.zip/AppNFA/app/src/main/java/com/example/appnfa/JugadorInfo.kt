package com.example.appnfa

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

// Objeto PlayerDetails con la información detallada del jugador
data class PlayerDetails(
    val playerName: String,
    val teamName: String,
    val totalGamesPlayed: Int,
    val averagePoints: Float,
    val pointsInSelectedMatch: Int,
    val detailedInfo: String // Información detallada del jugador, probablemente una descripción larga
)

@Composable
fun PlayerDetailScreen(player: PlayerDetails) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(
                text = player.playerName,
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "${player.teamName} | Partidos jugados: ${player.totalGamesPlayed} | Media de puntos: ${player.averagePoints}",
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Puntos en el partido seleccionado: ${player.pointsInSelectedMatch}",
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Información detallada del jugador:",
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = player.detailedInfo,
                overflow = TextOverflow.Clip,
                maxLines = Int.MAX_VALUE
            )
        }
    }
}

// Previsualización de la pantalla de detalle del jugador
@Preview
@Composable
fun PlayerDetailScreenPreview() {
    val player = PlayerDetails(
        playerName = "Lebron James",
        teamName = "Los Angeles Lakers",
        totalGamesPlayed = 50,
        averagePoints = 28.5f,
        pointsInSelectedMatch = 30,
        detailedInfo = "Información detallada del jugador obtenida de la Wiki o una fuente similar. Aquí puede ser una descripción larga del jugador."
    )
    PlayerDetailScreen(player = player)
}
