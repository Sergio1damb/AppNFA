package com.example.appnfa

import android.os.Bundle
import android.widget.DatePicker
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.appnfa.ui.theme.AppNFATheme
import java.util.Calendar
import java.util.Date

data class PlayerMatchStats(
    val playerName: String,
    val teamName: String,
    val positionsPlayed: List<String>,
    val pointsScored: Int,
    val opposingTeam: String,
    val matchDate: Date
)

class MainActivity : ComponentActivity() {
    private val playerStatsList = mutableStateListOf<PlayerMatchStats>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppNFATheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    PlayerListScreen(
                        players = playerStatsList,
                        teams = listOf("Team A", "Team B", "Team C"),
                        onDeletePlayers = { players -> playerStatsList.removeAll(players) },
                        onAddPlayer = {
                            CreatePlayerScreen { player ->
                                playerStatsList.add(player)
                            }
                        }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerListScreen(
    players: List<PlayerMatchStats>,
    teams: List<String>,
    onDeletePlayers: (List<PlayerMatchStats>) -> Unit,
    onAddPlayer: () -> Unit,
    modifier: Modifier = Modifier
) {
    var searchText by remember { mutableStateOf("") }
    var selectedTeam by remember { mutableStateOf("") }
    var isDeleteMode by remember { mutableStateOf(false) }

    val playersToShow = remember {
        derivedStateOf {
            if (searchText.isEmpty() && selectedTeam.isEmpty()) {
                players
            } else if (selectedTeam.isNotEmpty()) {
                players.filter { it.teamName == selectedTeam }
            } else {
                players.filter { it.playerName.contains(searchText, ignoreCase = true) }
            }
        }
    }

    var selectedPlayers = remember { mutableStateListOf<PlayerMatchStats>() }

    Surface(modifier = modifier) {
        Column(modifier = Modifier.padding(16.dp)) {
            TextField(
                value = searchText,
                onValueChange = { searchText = it },
                label = { Text("Buscar jugadores por equipo") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            DropdownMenu(
                expanded = selectedTeam.isNotEmpty(),
                onDismissRequest = { selectedTeam = "" }
            ) {
                teams.forEach { team ->
                    DropdownMenuItem(onClick = { selectedTeam = team }) {
                        Text(text = team)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn(modifier = Modifier.weight(1f)) {
                items(playersToShow.value) { player ->
                    val isSelected = remember { mutableStateOf(false) }

                    PlayerItem(
                        player = player,
                        onDeletePlayer = { selectedPlayers.add(it) },
                        isDeleteMode = isDeleteMode,
                        isSelected = isSelected
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                ExtendedFloatingActionButton(
                    text = { Text("Añadir Jugador") },
                    onClick = onAddPlayer,
                    icon = {
                        Icon(
                            imageVector = Icons.Filled.Add,
                            contentDescription = "Add Player"
                        )
                    },
                    modifier = Modifier.padding(8.dp),
                    enabled = !isDeleteMode
                )

                ExtendedFloatingActionButton(
                    text = { Text(if (isDeleteMode) "Cancelar Borrado" else "Borrar Jugador") },
                    onClick = {
                        if (isDeleteMode) {
                            // Eliminar los jugadores seleccionados de la lista de jugadores
                            onDeletePlayers(selectedPlayers)
                            selectedPlayers.clear()
                            isDeleteMode = false
                        } else {
                            isDeleteMode = true
                        }
                    },
                    icon = {
                        Icon(
                            imageVector = Icons.Filled.Delete,
                            contentDescription = if (isDeleteMode) "Cancelar Borrado" else "Borrar Jugador"
                        )
                    },
                    modifier = Modifier.padding(8.dp)
                )
            }
        }
    }
}

@Composable
fun PlayerItem(
    player: PlayerMatchStats,
    onDeletePlayer: (PlayerMatchStats) -> Unit,
    isDeleteMode: Boolean,
    isSelected: MutableState<Boolean>
) {
    val backgroundColor = when (player.teamName) {
        "Team A" -> Color.Red
        "Team B" -> Color.Blue
        "Team C" -> Color.Green
        else -> Color.Gray
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .background(color = backgroundColor)
    ) {
        if (isDeleteMode) {
            Checkbox(
                checked = isSelected.value,
                onCheckedChange = { isSelected.value = it },
                modifier = Modifier.align(Alignment.CenterVertically)
            )
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .padding(start = 8.dp)
        ) {
            Text(text = player.playerName)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "VS ${player.opposingTeam}, ${player.matchDate}")
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "${player.pointsScored} PP")
        }

        if (!isDeleteMode) {
            IconButton(
                onClick = { onDeletePlayer(player) },
                modifier = Modifier.align(Alignment.CenterVertically)
            ) {
                Icon(
                    imageVector = Icons.Filled.Delete,
                    contentDescription = "Delete Player"
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreatePlayerScreen(onCreatePlayer: (PlayerMatchStats) -> Unit) {
    var playerName by remember { mutableStateOf(TextFieldValue()) }
    var teamName by remember { mutableStateOf(TextFieldValue()) }
    var selectedPositions by remember { mutableStateOf(mutableListOf<String>()) }
    var pointsScored by remember { mutableStateOf(0) }
    var opposingTeam by remember { mutableStateOf(TextFieldValue()) }
    var matchDate by remember { mutableStateOf(Calendar.getInstance()) }

    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text("Crear Nuevo Jugador", style = MaterialTheme.typography.headlineLarge)

            // ... Otros campos de entrada

            Spacer(modifier = Modifier.height(16.dp))

            DatePicker(
                date = matchDate,
                onDateChange = { matchDate = it },
                displayMode = DisplayMode.Dialog, // Modo de visualización como diálogo
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Seleccionar la fecha del partido") }
            )

            Spacer(modifier = Modifier.height(24.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { /* Navegar atrás o cerrar la pantalla */ },
                    modifier = Modifier.padding(end = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.ArrowBack,
                        contentDescription = "Back"
                    )
                }

                IconButton(
                    onClick = {
                        // Crear el objeto PlayerMatchStats con los datos ingresados
                        val player = PlayerMatchStats(
                            playerName = playerName.text,
                            teamName = teamName.text,
                            positionsPlayed = selectedPositions,
                            pointsScored = pointsScored,
                            opposingTeam = opposingTeam.text,
                            matchDate = matchDate.time
                        )
                        // Llamar a la función para crear el jugador
                        onCreatePlayer(player)
                    }
                ) {
                    Icon(
                        imageVector = Icons.Filled.ExitToApp,
                        contentDescription = "Save"
                    )
                }
            }
        }
    }
}

// Para previsualizar la pantalla
@Preview
@Composable
fun CreatePlayerScreenPreview() {
    CreatePlayerScreen(onCreatePlayer = {})
}
